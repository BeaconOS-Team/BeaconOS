from .with_pynput import advpass
from .without_pynput import askpass